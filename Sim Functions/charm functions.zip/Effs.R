Effs <- function(M_it,                 # M_it: health state occupied by individual i at cycle t
                 x_i=NULL) {         # x_i: matrix of individual characteristics

  u_it <- v.utilities[match(M_it, v.n_asthma)]

  
}